Steps
1.  sudo pip3 install numpy
2.  sudo pip3 install scipy
3.  sudo pip3 install summa
4.  sudo pip3 install pattern3
5.  Add text to be summarised and featured in text.txt.
6.  run ...python3 sum.py
7.  get result in summary.txt and feature.txt